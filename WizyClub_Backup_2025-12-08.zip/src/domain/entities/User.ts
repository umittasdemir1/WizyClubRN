export interface User {
    id: string;
    username: string;
    avatarUrl: string;
    isFollowing: boolean;
}
