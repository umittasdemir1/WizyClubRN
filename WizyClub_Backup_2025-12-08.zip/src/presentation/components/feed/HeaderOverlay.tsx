import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useEffect } from 'react';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withRepeat,
    withSequence,
    withTiming,
    Easing,
    cancelAnimation,
} from 'react-native-reanimated';
import { useBrightnessStore } from '../../store/useBrightnessStore';

// Import SVGs
import VoiceOnIcon from '../../../../assets/icons/voice_on.svg';
import SunIcon from '../../../../assets/icons/sun.svg';

// Brightness Button sub-component
function BrightnessButton() {
    const { brightness, toggleController } = useBrightnessStore();
    const isActive = brightness < 1.0;

    return (
        <Pressable
            style={styles.iconButton}
            onPress={toggleController}
            hitSlop={12}
        >
            <SunIcon
                width={24}
                height={24}
                color={isActive ? '#FFD700' : 'white'}
            />
        </Pressable>
    );
}

interface HeaderOverlayProps {
    isMuted: boolean;
    onToggleMute: () => void;
    onStoryPress: () => void;
    onMorePress: () => void;
    hasUnseenStories?: boolean;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function HeaderOverlay({
    isMuted,
    onToggleMute,
    onStoryPress,
    onMorePress,
    hasUnseenStories = false,
}: HeaderOverlayProps) {
    const insets = useSafeAreaInsets();
    const pulseOpacity = useSharedValue(1);

    // Pulse animation when unmuted
    useEffect(() => {
        if (!isMuted) {
            pulseOpacity.value = withRepeat(
                withSequence(
                    withTiming(0.6, { duration: 800, easing: Easing.inOut(Easing.ease) }),
                    withTiming(1, { duration: 800, easing: Easing.inOut(Easing.ease) })
                ),
                -1,
                true
            );
        } else {
            cancelAnimation(pulseOpacity);
            pulseOpacity.value = withTiming(0.5, { duration: 200 });
        }
    }, [isMuted]);

    const voiceAnimatedStyle = useAnimatedStyle(() => ({
        opacity: pulseOpacity.value,
    }));

    return (
        <View style={[styles.container, { paddingTop: insets.top + 16 }]} pointerEvents="box-none">
            {/* Left: Voice Button - NO shadow, NO background */}
            <AnimatedPressable
                onPress={onToggleMute}
                style={[styles.iconButton, voiceAnimatedStyle]}
                hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            >
                <VoiceOnIcon
                    width={28}
                    height={28}
                    color={isMuted ? "#6B7280" : "#FFFFFF"}
                />
            </AnimatedPressable>

            {/* Center: Stories Pill */}
            <Pressable
                onPress={onStoryPress}
                style={styles.storiesPill}
                hitSlop={{ top: 8, bottom: 8 }}
            >
                <Text style={styles.storiesText}>Hikayeler</Text>
                {hasUnseenStories && (
                    <View style={styles.badge} />
                )}
            </Pressable>

            {/* Right: Brightness - toggles brightness controller */}
            <View style={styles.rightButtons}>
                <BrightnessButton />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
    },
    iconButton: {
        padding: 8,
        // NO background, NO shadow
    },
    storiesPill: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.15)',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 24,
        gap: 8,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.2)',
        // Glass shadow
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 5,
    },
    storiesText: {
        color: 'white',
        fontSize: 15,
        fontWeight: '700',
    },
    chevron: {
        color: 'rgba(255, 255, 255, 0.8)',
        fontSize: 8,
        marginTop: 1,
    },
    badge: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: '#FF3B30',
    },
    rightButtons: {
        flexDirection: 'row',
        gap: 8,
    },
});
